T = int(input())

for tc in range(1, T+1):
    N = int(input())

    board = [[0 for j in range(N)] for i in range(N)]

    for i in range(N):
        board[i] = list(map(int, input().split()))

